# Vinted Assistant

## Installation (2 minutes)
1. Dézippe le dossier `vinted-assistant` quelque part où il restera (ex. Documents).
2. Dans Chrome, ouvre `chrome://extensions`.
3. Active le **Mode développeur** (en haut à droite).
4. Clique sur **Charger l'extension non empaquetée** et choisis le dossier `vinted-assistant`.
5. Épingle l'extension (icône puzzle) et clique dessus : le panneau s'ouvre à droite.

## Réglages
- **Clé API** : créée sur console.anthropic.com → API Keys (commence par `sk-ant-`).
- **Modèle** : Haiku pour le quotidien, Sonnet si les étiquettes sont difficiles à lire.
- **Prochain SKU** : 16 par défaut (tu étais à P15). Il augmente tout seul.
- **Règles en plus** : consignes ponctuelles (ex. "lot de pulls Tommy → genre Femme").

## Annonces → brouillons Vinted (automatique)
Garde un onglet vinted.fr ouvert et connecté.
1. Dépose les photos d'un article : Claude l'analyse tout seul, puis crée le brouillon sur Vinted
   (photos, titre, description, catégorie, marque, taille, état, couleurs, matières, prix, colis).
2. Si un champ n'a pas pu être reconnu (ex. une taille), il est signalé en orange.
Ces deux automatismes se coupent dans les réglages (⚙︎).

## Photos depuis le téléphone
1. Sur le téléphone : installe OneDrive et active « Chargement de l'appareil photo ».
2. Sur le PC, les photos arrivent dans OneDrive\Images\Pellicule (ou « Camera Roll »).
3. Dans l'extension : « Relier le dossier photos du téléphone » → choisis ce dossier (une seule fois).
4. Ensuite : « Importer les nouvelles photos » ; les photos prises à moins de 2 min d'écart = un article.

## Brouillons (validation)
Liste tes brouillons Vinted. « Modifier » ouvre la page Vinted pour corriger.
Coche ceux qui sont bons → « Publier la sélection ». Rien n'est publié sans ton clic.

## Republier (onglet « Republier »)
Garde un onglet vinted.fr ouvert et connecté (l'extension en ouvre un si besoin).
1. Choisis le mode : « Publier la copie + supprimer l'ancienne » ou « Créer la copie en brouillon ».
2. Option : baisse de prix en % et pause entre deux annonces (45 s conseillé).
3. « À republier » montre les annonces en ligne depuis plus de 14 jours (réglable).
4. Coche les annonces (tri « les plus anciennes » ou « les moins vues ») puis « Republier la sélection ».
Sécurité : la nouvelle annonce est créée et vérifiée AVANT que l'ancienne soit supprimée.
Les favoris et les vues de l'ancienne annonce sont perdus.

## Favoris (onglet « Favoris »)
La liste des personnes qui ont mis un de tes articles en favori.
« Préparer » ouvre la conversation Vinted avec ton message déjà écrit (pseudo, article, prix remisé) :
tu relis et tu cliques toi-même sur Envoyer. L'extension n'envoie jamais de message seule.

## Prochaines étapes
- Création des brouillons Vinted directement depuis l'onglet Annonces.
- Assistant de négociation (réponses aux offres et messages).
