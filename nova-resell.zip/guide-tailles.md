# GUIDE ULTIME : reconnaissance du vêtement, du genre et de la taille (extension Vinted)

Rôle de ce guide : à partir des photos, l'IA doit déterminer (1) le type de vêtement, (2) la coupe, (3) le **genre**, (4) la **taille** (lettres, EU ou W/L). La conversion vers les tailles Vinted est déjà gérée par l'extension : ce guide ne la fait pas.

Toutes les mesures sont en **cm, vêtement posé à plat, non étiré**. Tolérance ±1,5 cm.

## Définition des mesures utilisées sur les photos
- **E = épaule à épaule** : de couture d'épaule à couture d'épaule. Utilisée pour les **coupes normales**.
- **A = aisselle à aisselle** : largeur de poitrine à plat, sous les manches. Utilisée pour les **oversize** et épaules tombantes.
- **L = longueur** : de la **couture d'épaule jusqu'en bas** du vêtement (côté dos ou face, bas du vêtement).
- **T = largeur de taille à plat** (ceinture, bord à bord) : pour jogging, jean, short.
- **J = longueur extérieure** : de la ceinture au bas de la jambe (côté).

Règle de lecture des photos : repérer le mètre ou la règle. Si le mètre est posé de couture d'épaule à couture d'épaule → E. S'il est posé d'une aisselle à l'autre → A. Une photo du bas du vêtement avec le mètre vertical → L. Si le type de mesure n'est pas identifiable → renvoyer `MESURE_NON_IDENTIFIEE`.

---

# PARTIE 1 : TABLEAUX DE MESURES

Pour chaque ligne, trouver d'abord la colonne E ou A qui correspond à la mesure photographiée, puis vérifier avec L.

## 1.1 Pull / sweat / sweat à capuche (coupe normale)

| Taille | HOMME E | HOMME A | HOMME L | FEMME E | FEMME A | FEMME L |
|---|---|---|---|---|---|---|
| XS | 41–43 | 49–51 | 60–63 | 35–37 | 44–46 | 52–56 |
| S | 43–45 | 52–54 | 62–65 | 37–39 | 47–49 | 54–58 |
| M | 45–47 | 55–57 | 64–68 | 39–41 | 50–52 | 56–61 |
| L | 47–49 | 58–60 | 66–70 | 41–43 | 53–56 | 58–63 |
| XL | 49–51 | 61–63 | 68–72 | 43–45 | 57–60 | 60–65 |
| XXL | 51–53 | 64–67 | 70–74 | 45–47 | 61–64 | 62–67 |
| XXXL | 53–55 | 68–71 | 72–76 | 47–49 | 65–68 | 64–69 |

Oversize / épaule tombante : seule A (et L) est fiable. Une pièce oversize mesure environ +4 à +8 cm de A par rapport à la taille de l'étiquette. Si la marque ou la coupe est oversize (voir 2.5), **retirer 6 cm à A** avant de chercher la taille dans la colonne A.

## 1.2 Veste légère (bomber, harrington, coach jacket, blouson, veste de survêtement zippée, trucker, polaire)

| Taille | HOMME E | HOMME A | HOMME L | FEMME E | FEMME A | FEMME L |
|---|---|---|---|---|---|---|
| XS | 42–44 | 51–53 | 62–65 | 36–38 | 45–47 | 50–55 |
| S | 44–46 | 54–56 | 64–67 | 38–40 | 48–50 | 52–57 |
| M | 46–48 | 57–59 | 66–70 | 40–42 | 51–53 | 54–60 |
| L | 48–50 | 60–62 | 68–72 | 42–44 | 54–57 | 56–62 |
| XL | 50–52 | 63–65 | 70–74 | 44–46 | 58–61 | 58–64 |
| XXL | 52–54 | 66–69 | 72–76 | 46–48 | 62–65 | 60–66 |
| XXXL | 54–56 | 70–73 | 74–78 | 48–50 | 66–69 | 62–68 |

Les bombers, trucker et vestes de survêt femme sont très courts : L ≤ 55 est un indice fort de femme.

## 1.3 Doudoune / parka (padded, plus ample)

| Taille | HOMME E | HOMME A | HOMME L | FEMME E | FEMME A | FEMME L |
|---|---|---|---|---|---|---|
| XS | 43–45 | 53–55 | 62–66 | 37–39 | 47–49 | 54–58 |
| S | 45–47 | 56–58 | 66–70 | 39–41 | 50–52 | 56–61 |
| M | 47–49 | 59–61 | 68–72 | 41–43 | 53–55 | 58–64 |
| L | 49–51 | 62–64 | 70–74 | 43–45 | 56–58 | 60–66 |
| XL | 51–53 | 65–67 | 72–76 | 45–47 | 59–62 | 62–68 |
| XXL | 53–55 | 68–71 | 74–78 | 47–49 | 63–66 | 64–70 |
| XXXL | 55–57 | 72–75 | 76–80 | 49–51 | 67–70 | 66–72 |

Une doudoune femme courte (L ≤ 60) ou ceinturée est quasi toujours femme. Une doudoune homme boxy à L ≥ 68 est homme.

## 1.4 Polo

| Taille | HOMME E | HOMME A | HOMME L | FEMME E | FEMME A | FEMME L |
|---|---|---|---|---|---|---|
| XS | 40–42 | 46–48 | 64–67 | 33–35 | 40–42 | 50–54 |
| S | 42–44 | 49–51 | 67–70 | 35–37 | 42–45 | 52–58 |
| M | 44–46 | 52–54 | 69–72 | 37–39 | 45–48 | 55–61 |
| L | 46–48 | 55–57 | 71–74 | 39–41 | 48–51 | 57–63 |
| XL | 48–50 | 58–60 | 73–76 | 41–43 | 51–54 | 59–65 |
| XXL | 50–52 | 61–64 | 75–78 | 43–45 | 54–57 | 61–67 |

## 1.5 T-shirt

| Taille | HOMME E | HOMME A | HOMME L | FEMME E | FEMME A | FEMME L |
|---|---|---|---|---|---|---|
| XS | 41–43 | 46–48 | 62–66 | 34–36 | 40–42 | 48–54 |
| S | 43–45 | 49–51 | 66–69 | 36–38 | 42–45 | 50–57 |
| M | 45–47 | 52–54 | 68–72 | 38–40 | 45–48 | 53–60 |
| L | 47–49 | 55–57 | 70–74 | 40–42 | 48–51 | 56–62 |
| XL | 49–51 | 58–60 | 72–76 | 42–44 | 51–54 | 58–64 |
| XXL | 51–53 | 61–64 | 74–78 | 44–46 | 54–57 | 60–66 |

Un tee-shirt femme court (L ≤ 52) est cropped : indice fort de femme.

## 1.6 Jogging / bas de survêtement (élastique non étiré)

| Taille | HOMME T | HOMME J | FEMME T | FEMME J |
|---|---|---|---|---|
| XXS | – | – | 29–31 | 88–94 |
| XS | 33–35 | 94–98 | 31–33 | 90–96 |
| S | 36–38 | 96–100 | 33–35 | 92–98 |
| M | 39–41 | 99–103 | 35–38 | 94–100 |
| L | 42–44 | 101–105 | 38–41 | 96–102 |
| XL | 45–47 | 103–107 | 41–44 | 98–104 |
| XXL | 48–51 | 105–109 | 44–47 | 100–106 |
| XXXL | 52–55 | 107–111 | 47–50 | 102–108 |

Indices de genre : femme = hanches ≥ taille + 6 cm, entrejambe 65–76, taille haute et ajustée ; homme = hanches ≈ taille + 3 à 5 cm, entrejambe 72–82, coupe droite.

## 1.7 Jean (denim non stretch : W = T ÷ 1,27)

| T (taille à plat) | Taille W | Genre le plus probable |
|---|---|---|
| 30–31 | W24 | Femme |
| 32 | W25 | Femme |
| 33–34 | W26–27 | Femme |
| 35–36 | W28 | Femme ou homme (voir indices) |
| 37 | W29 | Homme ou femme |
| 38 | W30 | Homme (femme possible) |
| 39–40 | W31 | Homme ou femme |
| 41 | W32 | Homme |
| 42–43 | W33–34 | Homme |
| 44–46 | W35–36 | Homme |
| 47–49 | W37–38 | Homme |

Zone d'ambiguïté W28–W31 : trancher avec l'entrejambe (homme 76–86, femme 68–81), la braguette (homme ≥ 17 cm, femme ≤ 15 cm), la forme des poches arrière et la hauteur de taille. L (longueur du jean) en pouces : entrejambe 81 cm = L32, 86 cm = L34. Si le jean est stretch, la mesure peut être 2 à 4 cm plus petite que la taille réelle : ne pas descendre d'une taille pour autant.

## 1.8 Short

| Taille | HOMME T | HOMME J | FEMME T | FEMME J |
|---|---|---|---|---|
| XS | 33–35 | 40–46 | 31–33 | 24–34 |
| S | 36–38 | 42–48 | 33–35 | 26–36 |
| M | 39–41 | 44–50 | 35–38 | 28–38 |
| L | 42–44 | 46–52 | 38–41 | 30–40 |
| XL | 45–47 | 48–54 | 41–44 | 32–42 |
| XXL | 48–51 | 50–56 | 44–47 | 34–44 |

Short mi-cuisse (J ≤ 40) = presque toujours femme. Short basket ou cargo long (J ≥ 46) = presque toujours homme.

## 1.9 Survêtement complet
Traiter le haut avec 1.2 (veste) ou 1.1 (sweat), et le bas avec 1.6. Le genre du survêtement = genre du haut ; si haut et bas se contredisent → `GENRE_INCERTAIN`.

## 1.10 Casquette
Pas de mesure à plat. Le genre n'est quasi jamais déterminant : renvoyer « mixte », sauf étiquette « Women/Femme/Wmn » (→ femme) ou « Kids/Junior » (→ enfant). La taille est « taille unique » si sangle ou snapback ; sinon lire l'étiquette (S/M ≈ 55–57 cm, L/XL ≈ 58–61 cm de tour de tête). Ne jamais déclencher l'arrêt pour une casquette.

## 1.11 Correspondance étiquettes particulières
- **Lacoste homme** : 2 = XS, 3 = S, 4 = M, 5 = L, 6 = XL, 7 = XXL, 8 = XXXL. **Lacoste femme** : 34 = XS, 36 = S, 38 = M, 40 = L, 42 = XL, 44 = XXL.
- **Femme EU** : 32 = XXS, 34 = XS, 36 = S, 38 = M, 40 = L, 42 = XL, 44 = XXL, 46 = XXXL.
- **Homme EU** : 44 = XS, 46 = S, 48 = M, 50 = L, 52 = XL, 54 = XXL, 56 = XXXL.
- **UK / US** : en vestes, la taille US homme est numérotée en tour de poitrine en pouces (ex. 38 = S, 40 = M, 42 = L, 44 = XL).

---

# PARTIE 2 : RECONNAISSANCE PAR LES PHOTOS

## 2.1 Reconnaître le type de vêtement (ordre : forme, fermeture, col, matière)
- **Doudoune** : matelassé (cloisons horizontales visibles), capuche ou col montant, souvent logo de poitrine ; épaisseur visible aux poignets.
- **Parka** : longue (L ≥ 85), capuche, souvent fourrure ou doublure ; classée avec la doudoune.
- **Veste légère** : zip intégral, col droit ou bomber, manches ajustées ou élastiquées ; pas de matelassage.
- **Polaire** : matière texturée, zip intégral ou demi-zip, souvent Columbia ou The North Face.
- **Sweat à capuche** : capuche + poche kangourou. **Sweat** : col rond, tissu molleton, côtes aux poignets.
- **Pull** : maille tricotée, col rond, V ou roulé, sans capuche.
- **Polo** : col chemise + patte de boutons courte.
- **T-shirt** : manches courtes, col rond, pas de boutons.
- **Jogging** : taille élastique, cordon, bas de jambe en bord-côte ou droit.
- **Jean** : denim, 5 poches, braguette zippée, rivets.
- **Short** : jambes coupées, taille élastique ou boutonnée.
- **Survêtement** : haut + bas du même tissu (la photo ou le titre le montre ensemble).
- **Casquette** : visière, sangle ou fermeture ajustable.

## 2.2 Reconnaître la coupe
- **Normale** : épaule posée sur la couture de l'épaule ; manches de longueur régulière. → utiliser **E**.
- **Oversize / épaule tombante** : couture d'épaule visiblement plus bas que l'épaule, manches longues, vêtement très large. → utiliser **A**.
- Si les deux sont photographiées, la mesure à privilégier dépend de la coupe : E pour normale, A pour oversize. Si E et A sont toutes deux disponibles, utiliser E pour le genre et A pour la taille.

## 2.3 Indices visuels du genre (à lire avant les mesures)
Chaque indice donne un score. Plus il y a d'indices dans le même sens, plus la décision est sûre.

**Indices femme**
- Étiquette « Women », « W », « Wmn », « Donna », « Damen », « Femme » ; tailles numériques 34–46 ; coupe cintrée ; longueur courte ; col plus petit.
- Fermeture : **zip, boutons ou ouverture qui se ferme de la gauche vers la droite** (côté droit du vêtement porté).
- Logo de la ligne femme (ex. Nike Sportswear W, Adidas Originals Women, Columbia Women, TNF Women's).
- Poitrine ou taille marquée, ceinture, volants, coupe cropped.

**Indices homme**
- Étiquette « Men », « Homme », « Uomo », « Herren », « M » (taille en lettres sans mention femme) ; tailles numériques 44–56 ou 3–8 (Lacoste).
- Fermeture : **zip ou boutons qui se ferment de la droite vers la gauche** (côté gauche du vêtement porté).
- Coupe droite, boxy, longue ; col plus large ; épaules plus larges (voir tableaux).
- Logos de ligne homme (Carhartt WIP, Lacoste L.12.12, Ralph Lauren Big Pony homme).

**Règle de la fermeture** : à utiliser en soutien, jamais seule (les marques de sport font des modèles mixtes).

## 2.4 Ordre de décision (obligatoire)
1. **Étiquette lisible** (texte « Men/Women » ou taille numérique typée) → genre trouvé. Les mesures servent seulement à vérifier la taille.
2. **Taille lue sur l'étiquette sans mention de genre** : prendre les indices visuels (2.3) puis la marque (2.5), puis confirmer avec les mesures.
3. **Pas d'étiquette** : appliquer la logique des mesures ci-dessous.

### Coupe normale, mesure E et L (haut)
- E ≤ 40 → **femme**. E ≥ 44 → **homme**.
- E entre 40 et 44 : regarder L. L ≤ 62 → femme ; L ≥ 66 → homme ; entre les deux → indices visuels (2.3) ; toujours rien → `GENRE_INCERTAIN`.
- Cohérence : le couple (E, L) doit tomber dans la **même taille** et le **même genre** des tableaux. Si E donne femme et L donne homme (ou l'inverse) → `GENRE_INCERTAIN`.

### Oversize, mesure A et L (haut)
- L ≤ 62 → **femme probable**. L ≥ 70 → **homme probable**. 62–70 → zone d'ambiguïté.
- Combiner avec les indices visuels. S'il n'y a qu'un indice faible → `GENRE_INCERTAIN`.
- Pour la taille : appliquer la correction de 6 cm (voir 1.1) si la coupe est oversize.

### Bas (jogging, jean, short)
- Utiliser T, J et les indices du tableau correspondant (1.6 à 1.8). Contradiction entre T et J → `GENRE_INCERTAIN`.

## 2.5 Particularités par marque (genre par défaut, coupe, pièges)

| Marque | Genre par défaut | Coupe | Particularités |
|---|---|---|---|
| Carhartt (dont WIP) | Homme | **Grande / oversize** pour sweats, vestes et Detroit | Épaule tombante : utiliser A. Corriger A de −6 cm sur les modèles boxy. Les modèles « W' » sont courts (L ≤ 58) et cintrés. |
| Dickies | Homme | Standard à grande | Presque tout homme ; modèles femme courts et étroits. Pantalons en W/L. |
| Levi's | Homme | Standard | Jeans en W/L. Trucker femme très courte (L ≤ 52, E ≤ 40). Jeans 501 homme droite, 501 femme taille haute. |
| Umbro | Homme | Standard | Peu de lignes femme ; si E ≤ 40 et L court (≤ 60) → femme. |
| Nike | Mixte | Standard ; Tech Fleece et lignes « Oversized » grandes | Lignes femme nettes (dos court, épaule basse). Les oversize femme ont un A proche de l'homme → utiliser L. |
| Adidas | Mixte | Standard | Originals femme courte (L ≈ 52–58). Lignes homme droites et longues (L ≈ 68–74). |
| The North Face | Homme | Standard à grande (Nuptse boxy) | Femme plus étroit et plus court : doudoune Nuptse homme L ≈ 70–75, femme ≈ 60–66. |
| Columbia | Mixte | Standard à petite en femme | Femme cintrée, épaule étroite ; polaire femme L ≈ 58–64 contre 68–72 homme. |
| Tommy Hilfiger | Mixte | Standard (ajusté en femme) | Femme E ≈ 38–40 en M. Pulls homme M : A 55–58, L 68–70. |
| Ralph Lauren | Mixte | Standard | Polos homme M : A 55–58, L 70–73. Polos femme M : A 47–51, L 60–64. Le Big Pony femme est plus long mais reste étroit. |
| Lacoste | Mixte | Standard (femme cintrée) | Polo L.12.12 homme M (taille 4) : A 54–57, L 71–73. Polo femme M (taille 38–40) : A 46–50, L 59–63. |

### Marques non listées (règle générale)
- Marques de **sport européennes** (Puma, Fila, Kappa, Champion EU, Reebok) : standard, genre mixte, appliquer les tableaux tels quels.
- Marques de **mode rapide** (Zara, H&M, Bershka, Pull&Bear, Jack & Jones en slim) : taillent petit, retirer 1 taille au résultat si la mesure est entre deux tailles.
- Marques **streetwear américaines** (Stüssy, Supreme, Essentials, Gap, Vans, Obey) : taillent grand, ajouter 1 taille à la lecture du tableau (ou retirer 6 cm à A).
- Marque inconnue : standard, et si tout est incertain → `GENRE_INCERTAIN`.

## 2.6 Cas où l'IA doit s'arrêter
L'extension se met en pause dès qu'une de ces conditions est vraie, puis reprend quand l'utilisateur a fourni l'info.

| Code | Condition | Info à demander |
|---|---|---|
| `GENRE_INCERTAIN` | Pas d'étiquette de genre lisible + mesures contradictoires ou dans une zone d'ambiguïté + indices visuels insuffisants | Étiquette de taille, photo du col, photo de la fermeture, ou genre choisi à la main |
| `MESURE_NON_IDENTIFIEE` | Impossible de dire si c'est E, A, L, T ou J | Photo avec le mètre bien visible et posé aux bons endroits |
| `TYPE_INCERTAIN` | Impossible de distinguer polo/t-shirt, veste/doudoune, etc. | Photo de face complète et du col |
| `MESURE_MANQUANTE` | E (ou A) ou L absente alors que la taille ne peut pas être déduite | La mesure manquante |
| `INCOHERENCE_TAILLE` | L'étiquette donne une taille, mais les mesures donnent une taille éloignée de 2 tailles ou plus | Vérifier l'étiquette ou les mesures |

Aucune de ces conditions ne s'applique aux casquettes.

Format de réponse recommandé de l'IA (JSON, pour l'extension) :
```
{
  "statut": "OK" | "STOP",
  "type": "pull | sweat | sweat_capuche | veste | doudoune | polo | tshirt | jogging | jean | short | survetement | casquette",
  "coupe": "normale | oversize",
  "mesure_utilisee": "E | A | L | T | J",
  "genre": "homme | femme | mixte",
  "taille": "M (ou EU 48 / W32 / Lacoste 4)",
  "confiance": "haute | moyenne | basse",
  "raisons": ["étiquette lisible", "E=46 → homme M", "fermeture droite→gauche"],
  "code_arret": null,
  "info_manquante": null
}
```
Si `statut = STOP`, remplir `code_arret` et `info_manquante`, puis ne rien publier.

## 2.7 Règles supplémentaires
1. **L'étiquette et les photos priment** sur les tableaux de mesures. Les tableaux servent à confirmer ou à déduire.
2. **Mesure entre deux tailles** : coupe normale ajustée → taille supérieure ; coupe large ou oversize → taille inférieure.
3. **Matières stretch** (jogging, jean stretch, polo piqué élastique) : la mesure à plat peut être 2 à 4 cm plus petite ; ne pas descendre d'une taille pour autant.
4. **Écart de confiance** : si la taille issue des mesures et celle de l'étiquette diffèrent d'une seule taille, garder l'étiquette (les marques varient).
5. **Vêtements enfants** (étiquette « Kids », « Junior », tailles 128–176 ou 8–16 ans) : hors scope des tableaux → `STOP` avec `TYPE_INCERTAIN` ou classement enfant selon ton extension.
6. **Ne jamais inventer** : si aucune règle ne permet de conclure, utiliser un code d'arrêt, jamais un genre choisi au hasard.

## 2.8 Limites
Ces fourchettes sont des moyennes basées sur les tailles standard EU et sur les coupes habituelles de chaque marque. Elles varient selon les modèles, les saisons et les années. Elles doivent être affinées avec tes retours réels : à chaque annonce corrigée à la main, noter la marque, la mesure et le genre correct pour ajuster les seuils.
